# Rei602-lokaverk

makeData.py: skjal með flest öllum hjálparföllum til að vinna úr gögnunum  
smallData.txt: feature-in okkar þar sem hver skrá í TPEHG dataset-inu er ein lína (ekki skipt eftir dummy/contraction period)  
contractionData.txt/dummyData.txt: feature-in okkar þar sem hvert period í hverri skrá í TPEHG dataset-inu er ein lína í viðeigandi skrá  
bigData.txt: feature-in okkar þar sem hver skrá í TPEHGT dataset-inu er ein lína
lokavrk SVM.ipynb: SVM flokkarinn okkar
lvrk CNN.ipynb: CNN flokkarinn okkar
Gervigreind-lokaverkefni.pdf: skýrslan okkar